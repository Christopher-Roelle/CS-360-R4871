package com.zybooks.inventorio;

public class Product {
    private int itemID;
    private String productName;
    private String location;
    private int quantity;

    public Product(int itemID, String productName, String location, int quantity)
    {
        this.itemID = itemID;
        this.productName = productName;
        this.location = location;
        this.quantity = quantity;
    }

    //Get/Sets
    public int GetItemID() {
        return itemID;
    }

    public void SetItemID(int itemID)
    {
        this.itemID = itemID;
    }

    public String GetProductName() {
        return productName;
    }

    public void SetProductName(String productName)
    {
        this.productName = productName;
    }

    public String GetLocation() {
        return location;
    }

    public void SetLocation(String location)
    {
        this.location = location;
    }

    public int GetQuantity() {
        return quantity;
    }

    public void SetQuantity(int quantity)
    {
        this.quantity = quantity;
    }

    //Functions
    public int IncrementQuantity()
    {
        quantity++;
        return quantity;
    }

    public int DecremenetQuantity()
    {
        quantity--;
        return quantity;
    }
}
